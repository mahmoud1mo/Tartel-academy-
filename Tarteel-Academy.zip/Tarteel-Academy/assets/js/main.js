// main.js
function toggleTheme() {
    const theme = document.getElementById("theme");
    if (theme.getAttribute("href") === "css/dark-mode.css") {
        theme.setAttribute("href", "css/light-mode.css");
    } else {
        theme.setAttribute("href", "css/dark-mode.css");
    }
}

// دالة حفظ البيانات الشخصية
function saveProfile() {
    alert("تم حفظ البيانات بنجاح!");
}

// دالة إرسال الاختبار
function submitQuiz() {
    alert("شكراً لك! سيتم تقييم إجاباتك قريبًا.");
}