// ai-tutor.js
function askAIQuestion() {
    const question = document.getElementById("questionInput").value.trim();
    if (!question) {
        alert("من فضلك أدخل سؤالك أولًا.");
        return;
    }

    // نموذج استجابة ثابتة (في المستقبل يمكنك ربطه بـ ChatGPT API)
    const responses = {
        "ما معنى سورة الفاتحة؟": "الفاتحة هي أم القرآن، وتفتح كتاب الله، وتتضمن الدعاء إلى الله والثناء عليه.",
        "كيف أحفظ القرآن؟": "ابدأ بالسور القصيرة، واستعن بشيخ متخصص، وخصص وقتًا يوميًا للحفظ والمراجعة.",
        "ما معنى الرحمن الرحيم؟": "الرحمن هو ذو الرحمة العامة التي تشمل كل خلقه، والرحيم هي الرحمة الخاصة المؤمنين."
    };

    let answer = "عذرًا، لا يمكنني الإجابة على هذا السؤال الآن.";
    for (let key in responses) {
        if (question.includes(key)) {
            answer = responses[key];
            break;
        }
    }

    document.getElementById("ai-answer").innerText = "🤖 الإجابة: " + answer;
}